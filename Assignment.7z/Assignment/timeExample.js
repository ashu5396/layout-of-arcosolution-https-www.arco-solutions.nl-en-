$(document).ready(function(){
    $('#upcoming_past').change(function(){
      
       $('#upcoming_past option:selected').each(function(){
            
        var result='';
        if($(this).val()=="upcoming")
            {
                $('#timeFinder').html("<option value='Select'>Select</option><option value='nexttfhours'>Next 24 Hours</option><option value='nextweek'>Next Week</option><option value='nextmonth'>Next Month</option><option value='nextthreemonth'>Next 3 Month</option>")
                $('#output2').html('');
            }
        
         else if($(this).val()=="past")
            {
                $('#timeFinder').html("<option value='Select'>Select</option><option value='past_one_month'>Past 1 Month</option><option value='past_three_months'>Past 3 Months</option><option value='past_six_months'>Past 6 Months</option><option value='past_one_year'>2018</option><option value='past_three_years'>2016</option><option value='past_six_years'>2013</option>")
                $('#output2').html('')
            }
           
            else 
            {
                var result='<b style="color:red;">*</b><bold style="color:red;">Please Select Upcoming/Past</bold>'
                $('#timeFinder').html("<option value='Select'>Select</option>")
                $('#output2').html('')
            }
            
            $('#output1').html('<div class="container"><b>'+result+'</b></div>');
       });




      
    });


    $('#timeFinder').change(function(){

        $('#timeFinder option:selected').each(function(){
            var result='';
                var dt= new Date();
                var year=dt.getFullYear();
                var month=dt.getMonth();
                var firstDay='';
                var lastDay='';
            if($(this).val()=='nexttfhours')
            {
                var milliseconds = new Date().getTime() + (24 * 60 * 60 * 1000);
                var newDate=new Date(milliseconds);
                result+='Next 24 Hours= '+'<font style="color:red;">' +newDate.toDateString()+'  --->  '+newDate.getHours()+':'+newDate.getMinutes()+':'+newDate.getSeconds()+'</font>';
            }
            else if($(this).val()=='nextweek')
            {
                var milliseconds = new Date().getTime() + (24*7 * 60 * 60 * 1000);
                var newDate=new Date(milliseconds);
                result+='Next Week= '+'<font style="color:red;">' +newDate.toDateString()+'  --->  '+newDate.getHours()+':'+newDate.getMinutes()+':'+newDate.getSeconds()+'</font>';
            
            }
            else if($(this).val()=='nextmonth')
            {
                
                
                firstDay=new Date(year,month+1,1);
                lastDay=new Date(year,month+2,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
            }
           else if($(this).val()=='nextthreemonth')
            {
                
                firstDay=new Date(year,month+3,1);
                lastDay=new Date(year,month+4,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
          
            }
            else if($(this).val()=='past_one_month')
            {
                firstDay=new Date(year,month-1,1);
                lastDay=new Date(year,month,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
          
            }
            
            else if($(this).val()=='past_three_months')
            {
                firstDay=new Date(year,month-3,1);
                lastDay=new Date(year,month-2,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
          
            }
            else if($(this).val()=='past_six_months')
            {
                firstDay=new Date(year,month-6,1);
                lastDay=new Date(year,month-5,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
          
            }
            else if($(this).val()=='past_one_year')
            {
                firstDay=new Date(year-1,month,1);
                lastDay=new Date(year-1,month+1,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
          

            }
            else if($(this).val()=='past_three_years')
            {
                firstDay=new Date(year-3,month,1);
                lastDay=new Date(year-3,month+1,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
          

            }
            else if($(this).val()=='past_six_years')
            {
                firstDay=new Date(year-6,month,1);
                lastDay=new Date(year-6,month+1,0);
               result+='First Day of the month= '+firstDay.toDateString()+'<br>Last Day of the Month='+lastDay.toDateString();
          

            }
            

            else
            {
                result+='<b style="color:red;">*</b><bold style="color:red;">Please Select Time</bold>';
            }
            $('#output2').html('<h6>'+result+'</h6>');
        });


    });
    
});